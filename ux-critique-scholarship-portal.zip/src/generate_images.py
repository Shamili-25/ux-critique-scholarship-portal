"""Draws 5 recreated, annotated screens of an illustrative scholarship-portal journey.
Requires Pillow. Run: python src/generate_images.py"""
from PIL import Image, ImageDraw, ImageFont
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FD = "/usr/share/fonts/truetype/dejavu/"
def font(sz, bold=False):
    try: return ImageFont.truetype(FD + ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"), sz)
    except OSError: return ImageFont.load_default()
W, H, SW = 1100, 640, 660
NAVY, GREY, RED, LIGHT = (30,58,95), (150,150,150), (200,30,30), (245,246,248)

def base(title):
    im = Image.new("RGB", (W,H), "white"); d = ImageDraw.Draw(im)
    d.rectangle([20,20,20+SW,H-20], fill=LIGHT, outline=(190,190,190))
    d.rectangle([20,20,20+SW,70], fill=NAVY)
    d.text((36,34), "Scholarship Portal (recreated for critique)", fill="white", font=font(16,True))
    d.text((20+SW+25,24), title, fill=NAVY, font=font(18,True))
    return im, d
def btn(d, box, label, fill=(70,110,170), fg="white"):
    d.rectangle(box, fill=fill); d.text((box[0]+10, box[1]+9), label, fill=fg, font=font(14))
def field(d, x, y, w, ph, h=34):
    d.rectangle([x,y,x+w,y+h], fill="white", outline=(170,170,170)); d.text((x+8,y+8), ph, fill=GREY, font=font(13))
def pin(d, x, y, n):
    d.ellipse([x-13,y-13,x+13,y+13], fill=RED); d.text((x-5,y-9), str(n), fill="white", font=font(14,True))
def legend(d, items):
    y = 62
    for n, t in items:
        pin(d, 20+SW+35, y+22, n)
        line, ly = "", y+8
        for w in t.split():
            if len(line)+len(w) > 36:
                d.text((20+SW+58, ly), line, fill=(40,40,40), font=font(13)); line, ly = "", ly+17
            line += w + " "
        d.text((20+SW+58, ly), line, fill=(40,40,40), font=font(13)); y = ly + 36
def save(im, name): im.save(os.path.join(ROOT,"images",name))

im,d = base("S1 Landing / entry")
d.text((50,100), "Welcome", font=font(22,True), fill=NAVY)
for i,l in enumerate(["Student Login","Institute Login","Verification"]): btn(d,(50,150+i*60,330,196+i*60),l)
d.text((50,350), "Fresh / Renewal registration  |  Guidelines.pdf", fill=(80,80,80), font=font(14))
d.text((50,560), "Footer: Copyright. Visitors: 9,81,22,114", fill=GREY, font=font(11))
pin(d,360,173,1); pin(d,630,357,2); pin(d,360,570,3)
legend(d,[(1,"Three unlabeled entry paths; user must guess which applies (Clarity)."),(2,"'Fresh/Renewal' jargon and a PDF as the only guidance (Clarity)."),(3,"No owner, contact or data-use statement (Trust).")])
save(im,"screen-1-landing.png")

im,d = base("S2 Registration")
for i,p in enumerate(["Full name","Government ID number","Email","Password"]): field(d,50,100+i*55,360,p)
d.rectangle([50,330,250,380], fill=(220,220,200), outline=(120,120,120)); d.text((70,342), "x7 Kq 2", font=font(20,True), fill=(110,110,90))
field(d,50,395,200,"Enter text shown"); btn(d,(50,455,200,495),"Register")
d.rectangle([430,100,640,160], fill=(255,225,225), outline=RED); d.text((440,120), "Invalid details", fill=RED, font=font(14,True))
pin(d,425,130,1); pin(d,265,350,2); pin(d,430,272,3)
legend(d,[(1,"Generic banner, does not say which field or why (Feedback)."),(2,"Distorted CAPTCHA, no audio or refresh (Accessibility)."),(3,"Password rules not shown until it fails (Error prevention).")])
save(im,"screen-2-registration.png")

im,d = base("S3 Profile form")
labels=["Name","Father name","DOB","Course","Year","Income","Bank","IFSC"]
for i in range(8): field(d,50+(i%2)*300,95+(i//2)*60,270,labels[i],h=30)
d.text((50,345), "... 32 more fields on this page ...", fill=GREY, font=font(14))
btn(d,(50,400,200,440),"Submit")
pin(d,45,110,1); pin(d,640,85,2); pin(d,230,420,3)
legend(d,[(1,"Labels are placeholders; vanish on typing; required fields unmarked (Clarity)."),(2,"No progress indicator or step count (Feedback)."),(3,"No autosave; session expires silently (Error prevention).")])
save(im,"screen-3-profile.png")

im,d = base("S4 Document upload")
d.text((50,100), "Upload Income Certificate", font=font(18,True), fill=NAVY)
d.text((50,135), "Upload the required file.", fill=(205,205,205), font=font(13))
btn(d,(50,170,200,210),"Choose file",fill=(120,120,120))
d.rectangle([50,250,520,300], fill=(255,225,225), outline=RED); d.text((60,265), "Error 1023: Upload failed", fill=RED, font=font(14,True))
pin(d,260,148,1); pin(d,545,275,2); pin(d,230,190,3)
legend(d,[(1,"Light-grey helper text on white, hard to read (Accessibility)."),(2,"Cryptic error code, no cause or next step (Feedback)."),(3,"File size and format limits never shown (Error prevention).")])
save(im,"screen-4-upload.png")

im,d = base("S5 Application status")
d.text((50,100), "Application Status", font=font(18,True), fill=NAVY)
d.rectangle([50,140,420,200], fill="white", outline=(170,170,170)); d.text((65,160), "Status: Pending at Level 1", font=font(15))
d.text((50,245), "(no timeline, no receipt number, no help link)", fill=GREY, font=font(13))
pin(d,440,170,1); pin(d,440,252,2)
legend(d,[(1,"'Level 1' is unexplained; no steps or expected time (Clarity)."),(2,"No receipt ID, email confirmation or help contact (Trust).")])
save(im,"screen-5-status.png")

names = ["screen-1-landing","screen-2-registration","screen-3-profile","screen-4-upload","screen-5-status"]
ims = [Image.open(os.path.join(ROOT,"images",n+".png")).resize((W//2,H//2)) for n in names]
ov = Image.new("RGB",(W//2*3, H//2*2),"white")
for i,m in enumerate(ims): ov.paste(m,((i%3)*(W//2),(i//3)*(H//2)))
ov.save(os.path.join(ROOT,"images","journey-overview.png"))
print("Images done")
