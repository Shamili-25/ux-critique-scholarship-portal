-- sqlite3 database/critique.db < src/queries.sql
SELECT * FROM v_severity_by_heuristic ORDER BY avg_severity DESC;
SELECT * FROM v_findings_by_screen;
SELECT f.finding_id, s.name, f.heuristic, f.severity, f.issue
FROM heuristic_findings f JOIN screens s USING (screen_id)
WHERE f.severity >= 4 ORDER BY f.severity DESC;
