"""Writes the CSV datasets and builds database/critique.db (SQLite).
Run: python src/build_db.py"""
import csv, sqlite3, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = lambda *p: os.path.join(ROOT, *p)

EVIDENCE_COLS = ["evidence_id","source","user_segment","observation","verbatim_quote",
                 "problem_signal","design_opportunity","confidence","privacy_note"]
NQ = "N/A - no participant yet (heuristic review)"
PN = "No personal data; screens recreated with dummy content"
evidence = [
("UX-001","Heuristic review","College fresher","Landing page offers three unlabeled entry buttons (Student / Institute / Verify) and uses terms like 'Fresh' and 'Renewal' without explanation",NQ,"User may pick the wrong path before starting","Plain-language entry cards: 'First-time applicant' vs 'Renewing'","Low",PN),
("UX-002","Heuristic review","College fresher","No statement of who runs the site, how data is used, or what documents are needed before registering",NQ,"Trust gap and surprise requirements","Pre-start checklist plus visible owner and data-use note","Low",PN),
("UX-003","Heuristic review","Career switcher","Password rules appear only after a failed attempt; CAPTCHA is distorted with no audio or refresh option",NQ,"Avoidable errors and an accessibility barrier","Show rules live while typing; offer accessible CAPTCHA alternative","Low",PN),
("UX-004","Heuristic review","College fresher","Registration form returns a generic banner 'Invalid details' without pointing to the field",NQ,"User cannot locate or fix the error","Inline field-level messages with fix instructions","Low",PN),
("UX-005","Heuristic review","Career switcher","Profile form has about 40 fields on one page with no progress indicator or autosave",NQ,"High effort and risk of losing data","Multi-step form with progress bar and autosave","Low",PN),
("UX-006","Heuristic review","College fresher","Labels exist only as placeholder text that disappears on typing; mandatory fields are not marked",NQ,"Memory load and screen-reader problems","Persistent visible labels; mark required fields","Low",PN),
("UX-007","Heuristic review","Career switcher","Session ends silently after inactivity with no warning",NQ,"Lost work causes frustration and distrust","Timeout warning with option to extend","Low",PN),
("UX-008","Heuristic review","College fresher","Upload fails with 'Error 1023' and size/format limits are never stated beforehand",NQ,"Unhelpful error and no prevention","State limits up front; explain failure in plain words","Low",PN),
("UX-009","Heuristic review","Career switcher","Upload helper text is light grey on white (low contrast)",NQ,"Instructions are hard to read","Meet WCAG AA contrast (4.5:1)","Low",PN),
("UX-010","Heuristic review","College fresher","Status screen shows only 'Pending at Level 1' with no timeline, receipt number or help contact",NQ,"User cannot tell what is happening or what to do","Plain status steps, expected timeline, receipt and help link","Low",PN),
]
screens = [
("S1","Landing / entry","Unlabeled entry buttons, jargon","images/screen-1-landing.png"),
("S2","Registration","Hidden password rules, generic error","images/screen-2-registration.png"),
("S3","Profile form","Long form, placeholder-only labels, no progress","images/screen-3-profile.png"),
("S4","Document upload","Cryptic error, limits unstated, low contrast","images/screen-4-upload.png"),
("S5","Status","Vague status, no timeline or help","images/screen-5-status.png"),
]
findings = [
("F01","S1","Clarity",3,"Jargon and unlabeled entry options","Use plain labels with one-line explanations","UX-001"),
("F02","S1","Trust",3,"No owner, data-use or document checklist shown","Add trust panel and pre-start checklist","UX-002"),
("F03","S2","Error prevention",3,"Password rules shown only after failure","Live rule checklist while typing","UX-003"),
("F04","S2","Accessibility",4,"Distorted CAPTCHA with no alternative","Provide audio/alternative challenge","UX-003"),
("F05","S2","Feedback",3,"Generic 'Invalid details' banner","Field-level inline errors","UX-004"),
("F06","S3","Clarity",3,"Placeholder-only labels; required fields unmarked","Persistent labels and required markers","UX-006"),
("F07","S3","Feedback",2,"No progress indicator","Step indicator (e.g. Step 2 of 5)","UX-005"),
("F08","S3","Error prevention",4,"No autosave; silent session timeout","Autosave and timeout warning","UX-007"),
("F09","S4","Feedback",4,"'Error 1023' gives no cause or fix","Plain-language error with next step","UX-008"),
("F10","S4","Error prevention",3,"File size/format limits not stated","Show limits beside the upload field","UX-008"),
("F11","S4","Accessibility",3,"Low-contrast helper text","Raise contrast to WCAG AA","UX-009"),
("F12","S5","Clarity",3,"'Pending at Level 1' is unexplained","Show steps and expected timeline","UX-010"),
("F13","S5","Trust",4,"No receipt number or help contact","Receipt ID, email confirmation, help link","UX-010"),
]
assumptions = [
("A1","Applicants fail mainly because document requirements and formats are unclear before they start","Task-based usability test with 5+ participants; record failed steps","Not validated"),
("A2","Inline errors, progress and autosave will cut failed or abandoned submissions","Prototype test: compare error counts and completion on old vs new flow","Not validated"),
("A3","Plain-language status plus a timeline will reduce helpdesk dependence and raise trust","Interviews plus helpdesk log review; trust rating before/after","Not validated"),
]
rq = ("RQ1","What causes first-time scholarship applicants to fail or abandon each step of the online application, and which interface changes would let them complete it and trust the result without outside help?")

def write_csv(name, cols, rows):
    with open(D("data", name), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)
write_csv("evidence.csv", EVIDENCE_COLS, evidence)
write_csv("screens.csv", ["screen_id","name","key_issue","image_path"], screens)
write_csv("heuristic_findings.csv", ["finding_id","screen_id","heuristic","severity","issue","recommendation","evidence_id"], findings)
write_csv("assumptions.csv", ["assumption_id","assumption","validation_method","status"], assumptions)

db = D("database","critique.db")
if os.path.exists(db): os.remove(db)
con = sqlite3.connect(db)
con.executescript(open(D("database","schema.sql"), encoding="utf-8").read())
con.executemany("INSERT INTO evidence VALUES (?,?,?,?,?,?,?,?,?)", evidence)
con.executemany("INSERT INTO screens VALUES (?,?,?,?)", screens)
con.executemany("INSERT INTO heuristic_findings VALUES (?,?,?,?,?,?,?)", findings)
con.executemany("INSERT INTO assumptions VALUES (?,?,?,?)", assumptions)
con.execute("INSERT INTO research_question VALUES (?,?)", rq)
con.commit(); con.close()
print("Built", db)
