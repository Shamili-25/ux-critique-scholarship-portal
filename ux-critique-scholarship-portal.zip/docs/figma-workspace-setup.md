# Figma Workspace Setup
Create a Figma file named **Interface Critique - Scholarship Portal** with these pages:

| Page | Put here |
|---|---|
| **Evidence** | The 5 annotated images from `images/` (or your real screenshots), one frame each, plus the findings table |
| **Research** | One-page canvas from `docs/research-question-canvas.md`, assumptions, evidence log |
| **Flows** | Current journey (S1 to S5) and a proposed flow, drawn as boxes and arrows |
| **UI** | Redesign screens only after the problem is approved |
| **Prototype** | Linked frames for the usability test |

Tips: drag PNGs onto the canvas; use red pins as comments; name frames `S1-Landing` etc. Paste the Figma share link into README under "Links".
