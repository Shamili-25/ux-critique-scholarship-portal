# Heuristic Review
Severity: 1 cosmetic, 2 minor, 3 major, 4 critical. Full data: `data/heuristic_findings.csv`.

| ID | Screen | Heuristic | Sev | Issue | Recommendation |
|---|---|---|---|---|---|
| F01 | S1 | Clarity | 3 | Jargon, unlabeled entry options | Plain labels with one-line help |
| F02 | S1 | Trust | 3 | No owner, data-use, checklist | Trust panel and pre-start checklist |
| F03 | S2 | Error prevention | 3 | Password rules appear after failure | Live rule checklist |
| F04 | S2 | Accessibility | 4 | Distorted CAPTCHA, no alternative | Audio/alternative challenge |
| F05 | S2 | Feedback | 3 | Generic "Invalid details" banner | Inline field errors |
| F06 | S3 | Clarity | 3 | Placeholder-only labels, required unmarked | Persistent labels, required markers |
| F07 | S3 | Feedback | 2 | No progress indicator | Step indicator |
| F08 | S3 | Error prevention | 4 | No autosave, silent timeout | Autosave, timeout warning |
| F09 | S4 | Feedback | 4 | "Error 1023" unexplained | Plain-language error with next step |
| F10 | S4 | Error prevention | 3 | Limits not shown | Show size/format beside field |
| F11 | S4 | Accessibility | 3 | Low-contrast helper text | WCAG AA (4.5:1) |
| F12 | S5 | Clarity | 3 | "Pending at Level 1" unexplained | Steps and timeline |
| F13 | S5 | Trust | 4 | No receipt or help contact | Receipt ID, email, help link |
