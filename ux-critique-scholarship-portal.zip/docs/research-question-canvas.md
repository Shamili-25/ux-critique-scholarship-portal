# One-Page Research Question Canvas

**Workflow:** Online scholarship application (register, fill profile, upload documents, track status)
**Users:** First-time applicants (college freshers) and career switchers applying for aid or courses

## Problem
Applicants meet unclear labels, hidden rules, cryptic errors and vague status messages, so they fail, abandon, or depend on others to finish.

## Primary research question
**What causes first-time scholarship applicants to fail or abandon each step of the online application, and which interface changes would let them complete it and trust the result without outside help?**

## Assumptions to validate
| ID | Assumption | How to validate |
|---|---|---|
| A1 | Applicants fail mainly because document requirements and formats are unclear before they start | Task-based usability test, 5+ participants; log failed steps |
| A2 | Inline errors, progress and autosave will cut failed or abandoned submissions | Prototype test; compare error counts and completion vs. old flow |
| A3 | Plain-language status plus a timeline will reduce helpdesk dependence and raise trust | Interviews, helpdesk log review, before/after trust rating |

## Annotated evidence (top issues)
| Screen | Evidence | Heuristic | Severity (1-4) |
|---|---|---|---|
| S2 Registration | Distorted CAPTCHA, no alternative (UX-003) | Accessibility | 4 |
| S3 Profile | No autosave, silent timeout (UX-007) | Error prevention | 4 |
| S4 Upload | "Error 1023" with no cause or fix (UX-008) | Feedback | 4 |
| S5 Status | No receipt ID or help contact (UX-010) | Trust | 4 |

Images: `images/screen-*.png`

## Success measures
Task completion rate, errors per task, time to complete, unaided completion, trust rating (1-5).

## Limits
Findings are expert-review based (confidence: Low) until validated with real users. Collect only consented, anonymised quotes.
