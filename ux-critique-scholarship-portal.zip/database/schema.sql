PRAGMA foreign_keys = ON;
CREATE TABLE research_question (rq_id TEXT PRIMARY KEY, question TEXT NOT NULL);
CREATE TABLE screens (
  screen_id TEXT PRIMARY KEY, name TEXT NOT NULL, key_issue TEXT, image_path TEXT);
CREATE TABLE evidence (
  evidence_id TEXT PRIMARY KEY, source TEXT, user_segment TEXT, observation TEXT,
  verbatim_quote TEXT, problem_signal TEXT, design_opportunity TEXT,
  confidence TEXT CHECK (confidence IN ('Low','Medium','High')), privacy_note TEXT);
CREATE TABLE heuristic_findings (
  finding_id TEXT PRIMARY KEY,
  screen_id TEXT NOT NULL REFERENCES screens(screen_id),
  heuristic TEXT NOT NULL CHECK (heuristic IN ('Clarity','Feedback','Error prevention','Accessibility','Trust')),
  severity INTEGER CHECK (severity BETWEEN 1 AND 4),
  issue TEXT, recommendation TEXT,
  evidence_id TEXT REFERENCES evidence(evidence_id));
CREATE TABLE assumptions (
  assumption_id TEXT PRIMARY KEY, assumption TEXT NOT NULL,
  validation_method TEXT, status TEXT DEFAULT 'Not validated');
CREATE VIEW v_severity_by_heuristic AS
  SELECT heuristic, COUNT(*) AS findings, ROUND(AVG(severity),2) AS avg_severity
  FROM heuristic_findings GROUP BY heuristic;
CREATE VIEW v_findings_by_screen AS
  SELECT s.screen_id, s.name, COUNT(f.finding_id) AS findings, MAX(f.severity) AS worst
  FROM screens s LEFT JOIN heuristic_findings f USING (screen_id) GROUP BY s.screen_id;
