# Interface Critique & Research Question Canvas
**Case:** Online scholarship application (illustrative public-service / education workflow)

Defines a defensible design problem **before any redesign screens are drawn**.

> Screens in `images/` are **recreated illustrations** with dummy content, built to show common portal problems. Replace them with your own real, anonymised screenshots before submitting. Evidence rows are from a heuristic review; no participants were interviewed yet.

## Deliverables
| Requirement | Where |
|---|---|
| Journey across 5 annotated screens | `images/screen-1..5-*.png`, `images/journey-overview.png` |
| Heuristic review (clarity, feedback, error prevention, accessibility, trust) | `docs/heuristic-review.md`, `data/heuristic_findings.csv` |
| 1 research question + 3 assumptions | `docs/research-question-canvas.md` |
| Evidence log (your template format) | `data/evidence.csv` |
| Figma workspace structure | `docs/figma-workspace-setup.md` |
| Database | `database/critique.db` (schema: `database/schema.sql`) |

## Journey
![Journey overview](images/journey-overview.png)

## Run
```bash
pip install pillow
python src/generate_images.py   # regenerate annotated screens
python src/build_db.py          # regenerate CSVs + SQLite DB
sqlite3 database/critique.db < src/queries.sql
```

## Structure
```
docs/  data/  database/  images/  src/
```
